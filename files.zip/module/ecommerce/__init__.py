print("Eccommerce initialized")
